// LLM Classroom - Premium Interactions & Animated Background

function initAnimatedBackground() {
  const canvas = document.getElementById('bg-canvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d', { alpha: true });
  let width = canvas.width = window.innerWidth;
  let height = canvas.height = window.innerHeight;

  const particles = [];
  const connectionDistance = 180;
  const particleCount = Math.min(42, Math.floor((width * height) / 28000));

  // Create elegant floating particles
  for (let i = 0; i < particleCount; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.22,
      vy: (Math.random() - 0.5) * 0.22,
      radius: Math.random() * 2.1 + 1.0,
      opacity: Math.random() * 0.55 + 0.28
    });
  }

  function resizeCanvas() {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  }

  window.addEventListener('resize', resizeCanvas);

  function drawBackground() {
    ctx.clearRect(0, 0, width, height);

    // Subtle professional grid
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.055)';
    ctx.lineWidth = 1;
    const gridSize = 65;

    for (let x = 0; x < width; x += gridSize) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }

    for (let y = 0; y < height; y += gridSize) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Draw very subtle connections (neural / data flow aesthetic)
    ctx.strokeStyle = 'rgba(99, 102, 241, 0.07)';
    ctx.lineWidth = 0.7;

    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const distance = Math.sqrt(dx * dx + dy * dy);

        if (distance < connectionDistance) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }

    // Draw particles with soft professional glow
    particles.forEach(p => {
      // Soft outer glow
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius * 3.8, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(163, 163, 172, ${p.opacity * 0.1})`;
      ctx.fill();

      // Core particle
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = `rgba(226, 232, 240, ${p.opacity})`;
      ctx.fill();
    });
  }

  function updateParticles() {
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;

      // Soft bounce
      if (p.x < 0 || p.x > width) {
        p.vx *= -1;
        p.x = Math.max(5, Math.min(width - 5, p.x));
      }
      if (p.y < 0 || p.y > height) {
        p.vy *= -1;
        p.y = Math.max(5, Math.min(height - 5, p.y));
      }
    });
  }

  function animate() {
    drawBackground();
    updateParticles();
    requestAnimationFrame(animate);
  }

  // Respect reduced motion
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  if (!prefersReducedMotion) {
    animate();
  } else {
    drawBackground();
  }
}

// Mobile Menu
function initMobileMenu() {
  const menuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');

  if (menuBtn && mobileMenu) {
    menuBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });
  }
}

// Newsletter Form
function initNewsletterForm() {
  const forms = document.querySelectorAll('.newsletter-form');
  
  forms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      const button = form.querySelector('button');
      const originalText = button.innerHTML;
      
      button.innerHTML = 'Thank you!';
      button.disabled = true;

      setTimeout(() => {
        alert("Thank you! You've been added to our newsletter.");
        form.reset();
        button.innerHTML = originalText;
        button.disabled = false;
      }, 1200);
    });
  });
}

// Initialize everything
function initLLMClassroom() {
  initAnimatedBackground();
  initMobileMenu();
  initNewsletterForm();

  // Smooth scroll for anchor links
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });
  });

  console.log('%c[LLM Classroom] Premium site initialized successfully.', 'color: #6366F1');
}

window.onload = initLLMClassroom;